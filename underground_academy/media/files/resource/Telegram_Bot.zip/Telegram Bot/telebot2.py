from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import ReplyKeyboardMarkup, ReplyKeyboardRemove, KeyboardButton
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from random import randint

bot = Bot(token='5999890636:AAF3aSLtWBBJ2J9mTnrIl6e21rJhNGDGS1I')
dp = Dispatcher(bot)

# Sample inventory items with attributes
inventory = {
    1: {'name': 'Apple', 'price': 1.99, 'quantity': 50, 'weight': '100g', 'type': 'Fruit', 'brand': 'Organic'},
    2: {'name': 'Banana', 'price': 0.99, 'quantity': 80, 'weight': '120g', 'type': 'Fruit', 'brand': 'Fairtrade'},
    3: {'name': 'Milk', 'price': 3.49, 'quantity': 20, 'weight': '1L', 'type': 'Dairy', 'brand': 'Fresh Farms'},
    4: {'name': 'Bread', 'price': 2.99, 'quantity': 30, 'weight': '500g', 'type': 'Bakery', 'brand': 'Artisan'},
    5: {'name': 'Cheese', 'price': 4.99, 'quantity': 15, 'weight': '250g', 'type': 'Dairy', 'brand': 'Parmigiano Reggiano'},
    6: {'name': 'Eggs', 'price': 2.49, 'quantity': 40, 'weight': '12 count', 'type': 'Poultry', 'brand': 'Free Range'},
    7: {'name': 'Chocolate', 'price': 1.99, 'quantity': 25, 'weight': '100g', 'type': 'Confectionery', 'brand': 'Lindt'},
    8: {'name': 'Coffee', 'price': 5.99, 'quantity': 10, 'weight': '500g', 'type': 'Beverages', 'brand': 'Starbucks'},
    9: {'name': 'Tea', 'price': 2.99, 'quantity': 15, 'weight': '100g', 'type': 'Beverages', 'brand': 'Lipton'},
    10: {'name': 'Chips', 'price': 1.49, 'quantity': 50, 'weight': '100g', 'type': 'Snacks', 'brand': 'Lays'}
}

# Creating a list of all inventory item names
inventory_names = [inventory[item]['name'] for item in inventory]

# Creating reply keyboard markup with inventory item names
keyboard1 = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
for item in inventory_names:
    keyboard1.add(item)

keyboard2 = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
keyboard2.add(KeyboardButton("Place Order"), KeyboardButton("Cancel Order"))

button1 = InlineKeyboardButton(text="🛍 View Cart", callback_data="view_cart")
button2 = InlineKeyboardButton(text="🛒 Checkout", callback_data="checkout")
keyboard_inline = InlineKeyboardMarkup().add(button1, button2)

# Dictionary to keep track of user's cart
cart = {}

# Function to display inventory items to the user
async def display_inventory(message: types.Message):
    response = 'Here are the available items:\n\n'
    for item in inventory:
        response += f"{inventory[item]['name']} - ${inventory[item]['price']}\n"
    response += "\nPlease select an item from the list."
    await message.reply(response, reply_markup=keyboard1)


# Function to add an item to user's cart
async def add_to_cart(message: types.Message):
    item_name = message.text
    if item_name in inventory_names:
        item_id = inventory_names.index(item_name) + 1
        if inventory[item_id]['quantity'] > 0:
            if item_id in cart:
                cart[item_id]['quantity'] += 1
            else:
                cart[item_id] = {'name': item_name, 'price': inventory[item_id]['price'], 'quantity': 1}
            inventory[item_id]['quantity'] -= 1
            await message.reply(f"{item_name} added to your cart.", reply_markup=keyboard_inline)
        else:
            await message.reply(f"Sorry, {item_name} is out of stock.")
    else:
        await message.reply("Invalid item selected, please try again.", reply_markup=keyboard1)


# Function to view user's cart
async def view_cart(call: types.CallbackQuery):
    if not cart:
        await call.message.answer("Your cart is empty.", reply_markup=keyboard_inline)
    else:
        response = 'Here is your cart:\n\n'
        total_price = 0
        for item in cart:
            response += f"{cart[item]['name']} - {cart[item]['quantity']} x ${cart[item]['price']}\n"
            total_price += cart[item]['quantity'] * cart[item]['price']
        response += f"\nTotal price: ${total_price}"
        await call.message.answer(response, reply_markup=keyboard_inline)


# Function to checkout user's cart
async def checkout(call: types.CallbackQuery):
    if not cart:
        await call.message.answer("Your cart is empty.", reply_markup=keyboard_inline)
    else:
        response = 'Thank you for shopping with us!\n\nHere is your receipt:\n\n'
        total_price = 0
        for item in cart:
            response += f"{cart[item]['name']} - {cart[item]['quantity']} x ${cart[item]['price']}\n"
            total_price += cart[item]['quantity'] * cart[item]['price']
        response += f"\nTotal price: ${total_price}\n\nYour order will be delivered soon!"
        await call.message.answer(response, reply_markup=ReplyKeyboardRemove())
        cart.clear()
        for item in inventory:
            inventory[item]['quantity'] += 5


@dp.message_handler(commands=['inventory'])
async def send_inventory(message: types.Message):
    await display_inventory(message)


@dp.message_handler()
async def process_order(message: types.Message):
    await add_to_cart(message)


@dp.callback_query_handler(text=["view_cart", "checkout"])
async def process_callback(call: types.CallbackQuery):
    if call.data == "view_cart":
        await view_cart(call)
    elif call.data == "checkout":
        await checkout(call)
    await call.answer()


