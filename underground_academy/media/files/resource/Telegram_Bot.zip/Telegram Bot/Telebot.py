# from aiogram import Bot, Dispatcher, executor, types
# import pyqrcode

# bot = Bot(token='6271719567:AAEUDdgXpRBw4E9uK6bTPJgdrguhRuU6jlo')
# dp = Dispatcher(bot)

# @dp.message_handler(commands=['start', 'help'])
# async def welcome(message: types.Message):
#     await message.reply("Hello! Im Gunther Bot, Please follow my YT channel")

# @dp.message_handler(commands=['logo'])
# async def logo(message: types.Message):
#     await message.answer_photo('https://avatars.githubusercontent.com/u/62240649?v=4')

# @dp.message_handler()
# async def qr(message: types.Message):
#     text = pyqrcode.create(message.text)
#     text.png('code.png', scale=5)
#     await bot.send_photo(chat_id=message.chat.id, photo=open('code.png', 'rb'))


# if __name__ == '__main__':
#     executor.start_polling(dp)




from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import ReplyKeyboardMarkup, ReplyKeyboardRemove, KeyboardButton
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from random import randint

bot = Bot(token='5999890636:AAF3aSLtWBBJ2J9mTnrIl6e21rJhNGDGS1I')
dp = Dispatcher(bot)

# Sample inventory items with attributes
inventory = {
    1: {'name': 'Apple', 'price': 1.99, 'quantity': 50, 'weight': '100g', 'type': 'Fruit', 'brand': 'Organic'},
    2: {'name': 'Banana', 'price': 0.99, 'quantity': 80, 'weight': '120g', 'type': 'Fruit', 'brand': 'Fairtrade'},
    3: {'name': 'Milk', 'price': 3.49, 'quantity': 20, 'weight': '1L', 'type': 'Dairy', 'brand': 'Fresh Farms'},
    4: {'name': 'Bread', 'price': 2.99, 'quantity': 30, 'weight': '500g', 'type': 'Bakery', 'brand': 'Artisan'},
    5: {'name': 'Cheese', 'price': 4.99, 'quantity': 15, 'weight': '250g', 'type': 'Dairy', 'brand': 'Parmigiano Reggiano'},
    6: {'name': 'Eggs', 'price': 2.49, 'quantity': 40, 'weight': '12 count', 'type': 'Poultry', 'brand': 'Free Range'},
    7: {'name': 'Chocolate', 'price': 1.99, 'quantity': 25, 'weight': '100g', 'type': 'Confectionery', 'brand': 'Lindt'},
    8: {'name': 'Coffee', 'price': 5.99, 'quantity': 10, 'weight': '500g', 'type': 'Beverages', 'brand': 'Starbucks'},
    9: {'name': 'Tea', 'price': 2.99, 'quantity': 15, 'weight': '100g', 'type': 'Beverages', 'brand': 'Lipton'},
    10: {'name': 'Chips', 'price': 1.49, 'quantity': 50, 'weight': '100g', 'type': 'Snacks', 'brand': 'Lays'}
}



button10 = InlineKeyboardButton(text="👋 button10", callback_data="randomvalue_of10")
button20 = InlineKeyboardButton(text="💋 button20", callback_data="randomvalue_of20")
button30 = InlineKeyboardButton(text=" button30", callback_data="randomvalue_of30")
button40 = InlineKeyboardButton(text="👋 button40", callback_data="randomvalue_of40")
button50 = InlineKeyboardButton(text="💋 button50", callback_data="randomvalue_of50")
button60 = InlineKeyboardButton(text=" button60", callback_data="randomvalue_of60")
button70 = InlineKeyboardButton(text="👋 button70", callback_data="randomvalue_of70")
button80 = InlineKeyboardButton(text="💋 button80", callback_data="randomvalue_of80")
button90 = InlineKeyboardButton(text=" button90", callback_data="randomvalue_of90")
button100 = InlineKeyboardButton(text=" button100", callback_data="randomvalue_of100")
keyboard_inline = InlineKeyboardMarkup().add(button10, button20 ,button30 , button40,button50 ,button60,button70 , button80 , button90 , button100)

keyboard = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True).add("👋 Apple!", "Orange","Peach","Mango","5","6","7","8","9","Done")


button1 = InlineKeyboardButton(text="👋 button1", callback_data="randomvalue_of1000")
button2 = InlineKeyboardButton(text="💋 button2", callback_data="randomvalue_of10000")
button3 = InlineKeyboardButton(text=" button3", callback_data="randomvalue_of100000")
keyboard_inline = InlineKeyboardMarkup().add(button1, button2)

keyboard1 = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True).add("👋 Hello!", "💋 Youtube","View Cart")


@dp.message_handler(commands=['random'])
async def random_answer(message: types.Message):
    await message.reply("Select a range:", reply_markup=keyboard_inline)


@dp.message_handler(commands=['start', 'help'])
async def welcome(message: types.Message):
    await message.reply("Hello! Im Gunther Bot, Please follow my YT channel", reply_markup=keyboard1)


@dp.callback_query_handler(text=["randomvalue_of10", "randomvalue_of100"])
async def random_value(call: types.CallbackQuery):
    if call.data == "randomvalue_of10":
        await call.message.answer(randint(1, 10))
    if call.data == "randomvalue_of20":
        await call.message.answer(randint(11, 20))
    if call.data == "randomvalue_of30":
        await call.message.answer(randint(21, 30))
    if call.data == "randomvalue_of40":
        await call.message.answer(randint(31, 40))
    if call.data == "randomvalue_of50":
        await call.message.answer(randint(41, 50))
    if call.data == "randomvalue_of60":
        await call.message.answer(randint(51, 60))
    if call.data == "randomvalue_of70":
        await call.message.answer(randint(61, 70))
    if call.data == "randomvalue_of80":
        await call.message.answer(randint(71, 80))
    if call.data == "randomvalue_of1000":
        await call.message.answer(randint(101, 1000))
    if call.data == "randomvalue_of10000":
        await call.message.answer(randint(1001, 10000))
    if call.data == "randomvalue_of100000":
        await call.message.answer(randint(10001, 100000))
    await call.answer()


@dp.message_handler()
async def kb_answer(message: types.Message):
    cost = 0
    cart = []
    if message.text == '👋 Hello!':
        await message.reply("Hi! How are you?")
    elif message.text == '💋 Youtube':
        await message.reply("https://youtube.com/gunthersuper")
    elif message.text == 'View Cart':
        response = 'Here are the available items:\n\n'
        for item in inventory:
            response += f"{inventory[item]['name']} - ${inventory[item]['price']}\n"
        response += "\nPlease select an item from the list."
        await message.reply(response, reply_markup=keyboard)   
    # elif message.text == 'Orange':
    #     cart.append("Orange")
    #     cost = cost + 10
    #     await message.reply("Orange Added to cart")
    else:
        if(message.text =="Done"):
            await message.reply("Your Order is" + str(cart) + str(cost))
        cart.append(message.text)
        cost += 10
        print(cart)
        await message.reply("abc", reply_markup=keyboard) 


executor.start_polling(dp)
