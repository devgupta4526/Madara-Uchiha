import logging
from typing import Dict

from aiogram import Bot, Dispatcher, types
from aiogram.types import CallbackQuery
from aiogram.utils import executor
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

logging.basicConfig(level=logging.INFO)

bot = Bot(token="your_token_here")
dp = Dispatcher(bot)

# A dictionary to store the current order of each user
store_orders = {}


# Inventory items with attributes
inventory_items = {
    "Burger": {
        "price": 5.99,
        "quantity": 10,
        "weight": "1/4 lb",
        "type": "Beef",
        "brand": "Store Brand"
    },
    "Fries": {
        "price": 2.99,
        "quantity": 20,
        "weight": "Large",
        "type": "French Fries",
        "brand": "Store Brand"
    },
    "Ice Cream": {
        "price": 3.49,
        "quantity": 5,
        "weight": "Pint",
        "type": "Vanilla",
        "brand": "Store Brand"
    },
    "Hot Dog": {
        "price": 4.99,
        "quantity": 15,
        "weight": "1/4 lb",
        "type": "Beef",
        "brand": "Store Brand"
    },
    "Salad": {
        "price": 6.99,
        "quantity": 8,
        "weight": "8 oz",
        "type": "Caesar",
        "brand": "Store Brand"
    },
    "Pizza": {
        "price": 8.99,
        "quantity": 5,
        "weight": "12 inch",
        "type": "Pepperoni",
        "brand": "Store Brand"
    },
    "Soda": {
        "price": 1.99,
        "quantity": 30,
        "weight": "20 oz",
        "type": "Coke",
        "brand": "Store Brand"
    },
    "Chicken Wings": {
        "price": 9.99,
        "quantity": 12,
        "weight": "1 lb",
        "type": "Buffalo",
        "brand": "Store Brand"
    },
    "Milkshake": {
        "price": 4.99,
        "quantity": 7,
        "weight": "16 oz",
        "type": "Chocolate",
        "brand": "Store Brand"
    },
    "Nachos": {
        "price": 7.99,
        "quantity": 10,
        "weight": "16 oz",
        "type": "Cheese",
        "brand": "Store Brand"
    }
}


@dp.message_handler(commands=['start'])
async def start_handler(message: types.Message):
    user_id = message.from_user.id
    store_orders[user_id] = {}
    await message.reply("Welcome to the store! You can use the following commands:\n"
                        "/add - Add items to your order\n"
                        "/remove - Remove items from your order\n"
                        "/view - View your current order\n"
                        "/checkout - Place your order")


@dp.message_handler(commands=['add'])
async def add_handler(message: types.Message):
    keyboard = InlineKeyboardMarkup()
    for item, attributes in inventory_items.items():
        keyboard.add(InlineKeyboardButton(f"{item} (${attributes['price']}) - {attributes['quantity']} remaining", callback_data=f'add {item}'))
    await message.reply("Please select an item to add to
