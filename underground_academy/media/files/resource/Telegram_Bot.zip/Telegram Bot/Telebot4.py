from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import ReplyKeyboardMarkup, ReplyKeyboardRemove, KeyboardButton
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from random import randint

bot = Bot(token='5999890636:AAF3aSLtWBBJ2J9mTnrIl6e21rJhNGDGS1I')
dp = Dispatcher(bot)

cart = {}

# Sample inventory items with attributes
inventory = {
    1: {'name': 'Apple', 'price': 1.99, 'quantity': 50, 'weight': '100g', 'type': 'Fruit', 'brand': 'Organic'},
    2: {'name': 'Banana', 'price': 0.99, 'quantity': 80, 'weight': '120g', 'type': 'Fruit', 'brand': 'Fairtrade'},
    3: {'name': 'Milk', 'price': 3.49, 'quantity': 20, 'weight': '1L', 'type': 'Dairy', 'brand': 'Fresh Farms'},
    4: {'name': 'Bread', 'price': 2.99, 'quantity': 30, 'weight': '500g', 'type': 'Bakery', 'brand': 'Artisan'},
    5: {'name': 'Cheese', 'price': 4.99, 'quantity': 15, 'weight': '250g', 'type': 'Dairy', 'brand': 'Parmigiano Reggiano'},
    6: {'name': 'Eggs', 'price': 2.49, 'quantity': 40, 'weight': '12 count', 'type': 'Poultry', 'brand': 'Free Range'},
    7: {'name': 'Chocolate', 'price': 1.99, 'quantity': 25, 'weight': '100g', 'type': 'Confectionery', 'brand': 'Lindt'},
    8: {'name': 'Coffee', 'price': 5.99, 'quantity': 10, 'weight': '500g', 'type': 'Beverages', 'brand': 'Starbucks'},
    9: {'name': 'Tea', 'price': 2.99, 'quantity': 15, 'weight': '100g', 'type': 'Beverages', 'brand': 'Lipton'},
    10: {'name': 'Chips', 'price': 1.49, 'quantity': 50, 'weight': '100g', 'type': 'Snacks', 'brand': 'Lays'}
}

# Welcome message
@dp.message_handler(commands=['start'])
async def welcome(message: types.Message):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    buttons = [KeyboardButton(text='🛍 Show inventory'), KeyboardButton(text='🛒 Show cart'),KeyboardButton(text='Add To Cart')]
    keyboard.add(*buttons)
    await message.reply("Welcome to the General Store! What would you like to do?", reply_markup=keyboard)

# Function to display inventory items
async def show_inventory(chat_id):
    for item in inventory.values():
        message = f"{item['name']}: {item['quantity']} x ${item['price']} ({item['brand']} {item['type']}, {item['weight']})"
        await bot.send_message(chat_id, message)

async def add_to_cart(chat_id, item_id, quantity):
    item = inventory[item_id]
    if item['quantity'] < quantity:
        await bot.send_message(chat_id, f"Sorry, we don't have enough {item['name']} in stock.")
    else:
        # Check if cart exists for user, create one if it doesn't
        if not cart.get(chat_id):
            cart[chat_id] = {}
        # Check if item already exists in cart, increment quantity if it does
        if cart[chat_id].get(item_id):
            cart[chat_id][item_id]['quantity'] += quantity
        else:
            # Add new item to cart
            cart[chat_id][item_id] = {'name': item['name'], 'quantity': quantity, 'price': item['price']}
        
        await bot.send_message(chat_id, f"{quantity} {item['name']} added to cart.")
    return


async def show_cart(chat_id):
    if not cart.get(chat_id):
        await bot.send_message(chat_id, "Your cart is empty.")
    else:
        total_price = 0
        message = "Your cart:\n\n"
        for item_id, item in cart[chat_id].items():
            subtotal = item['price'] * item['quantity']
            message += f"{item['name']}: {item['quantity']} x ${item['price']} = ${subtotal}\n"
            total_price += subtotal
        message += f"\nTotal price: ${total_price}"
        await bot.send_message(chat_id, message)


@dp.message_handler(lambda message: message.text == '🛍 Show inventory')
async def show_inventory_handler(message: types.Message):
    await show_inventory(message.chat.id)


@dp.message_handler(lambda message: message.text == '🛒 Show cart')
async def show_cart_handler(message: types.Message):
    await show_cart(message.chat.id)

@dp.message_handler(lambda message: message.text == 'Add To Cart')
async def add_cart_handler(message: types.Message):
    # Extract item_id and quantity from user's message
    try:
        item_id = int(message.reply_to_message.text.split(':')[0])
        quantity = int(message.text)
    except:
        await bot.send_message(message.chat.id, "Invalid input. Please reply to an item in the inventory list and enter a valid quantity.")
        return

    # Call add_to_cart function
    await add_to_cart(message.chat.id, item_id, quantity)



@dp.callback_query_handler(lambda callback_query: callback_query.data.startswith('add'))
async def add_item_to_cart(callback_query: types.CallbackQuery):
    item_id = int(callback_query.data.split('_')[1])
    await add_to_cart(callback_query.from_user.id, item_id, 1)
    await bot.answer_callback_query(callback_query.id, text="Item added to cart.")


if __name__ == '__main__':
     executor.start_polling(dp, skip_updates=True)

